Ces fichiers contiennent les heuristiques que nous avons réalisé durant cette SAE

La classe AlgorithmeInsertion est une classe abstraite dont les classes AlgorythmeInsertionLoin et 
AlgorithmeInsertionProche hérites. 